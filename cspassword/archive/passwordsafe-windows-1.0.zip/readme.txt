PasswordSafe 1.0
Copyright 2000 Chris Seaton
------------------------------------------------------------

IMPORTANT:
This program requires the Visual Basic 6.0 and run time files, these can be downloaded from http://www.chriseaton.co.uk/vbrun60sp3.EXE.
This program also requires the Microsoft Common Controls version 6.0, this can be downloaded from http://www.chrisseaton.co.uk/commonctl6.zip

Program Information:

PasswordSafe is a program that allows you to store all your password safely and easily in one place. The data is heavily encoded but will open in PasswordSafe in seconds (24 seconds for a 30,000 record file on a P 500). Please check back at my website for updates.

------------------------------------------------------------

Program History:

Version 1.0
- First release

------------------------------------------------------------

License:

This program is freeware, that means you can install the software on as many systems as you like and you may use the software without charge. You may NOT reverse engineer the software or alter it and then distribute it. You may distribute the software on any medium so long as this is done without charge. I am not responsible for the use of this software or any damage that it may cause. There is no guarantee that the software will run without fault or error. By accepting this license, you are agreeing that you understand the nature of freeware and you agree to the above terms.

------------------------------------------------------------

Contact info:

http://www.chrisseaton.co.uk
chris@chrisseaton.co.uk
(please DO NOT email me about lost passwords - there are no backdoors to the files and I cannot open them for your)